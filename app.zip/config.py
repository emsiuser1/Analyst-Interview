
def credentials():

	creds = {
		'username': '',
		'password': ''
	}

	return creds